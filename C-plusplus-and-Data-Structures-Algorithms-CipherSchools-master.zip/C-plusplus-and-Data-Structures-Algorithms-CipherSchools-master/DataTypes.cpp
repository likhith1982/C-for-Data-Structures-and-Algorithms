#include<iostream>
using namespace std;

int main()
{
    // Declare 2 variables and then assign them values of 3,5 and then add them
    
    int a;
    int b;

    a=3;
    b=5;

    cout<<a+b<<endl<<"a+b";

    cout<<a+b;
    cout<<endl;
    cout<<"a+b";

    return 0;
}