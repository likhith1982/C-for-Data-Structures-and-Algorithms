#include<iostream>
using namespace std;

int main()
{
    int a,b;
    int c,d;

    cout<<"Input 4 integers a,b,c and d"<<endl;

    cin>>a;
    cin>>b;
    cin>>c;
    cin>>d;

    //statement : a>b  c>d


    cout<<(a>b || c>d);

    //C++ interprets true as 1
    //C++ interprets false as 0

}



// Execute AND and OR statements and print out the boolean :




// Execute if else statement  :





// Switch case conditional statement :

