#include<iostream>
using namespace std;

int main()
{
    long long int a;
    int b;
    float c;

    //cout<<"The size of int is :"<<sizeof(b)<<" The size of long long int is:"<<sizeof(a);
    cout<<"The address of c is "<<&c<<endl<<"The address of b is "<<b;

    return 0; 
}