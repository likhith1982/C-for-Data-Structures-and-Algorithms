#include<iostream>  //This line means Header

using namespace std;  // std makes sure that cout is a part of "iostream"

int main()   //we have written a main "function"
{
   cout<<"Hello World";

   return 0;
}