#include<iostream>
using namespace std;

int main()
{
    /*
    // char r,o,h,i,t;
    // cin>>r>>o>>h>>i>>t;

    char name[1000];

    cout<<"Enter your name : ( Note: Enter # after the end of your name: )";

    int i=0;  // Initial value of i is 0

    while(name[i]!='#')  // Here i is the previous input
    {
        cin>>name[i];
        if(name[i]=='#') break;
        i++;  // When the name is being entered, the value of i is increasing
    }
    
    i=0;   // Again need to change the value of i to 0 before running the second while loop

    cout<<"The name you have just entered is "<<endl;

    while(name[i]!='#')   // We have again used i
    {
        cout<<name[i];
        i++;
    }
    */

    

    string name;  //over here string is a new datatype and not a name so string is similar to int, float, double

    cin>>name;

    cout<<name;



}